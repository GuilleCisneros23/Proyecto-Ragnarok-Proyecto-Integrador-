package com.example.fenris;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.os.Environment;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class GeneradorDeCodigosQR {

    public Bitmap QRs(String archivo, String nombreArchivo, Context contexto, FirebaseStorage cloud) {

        MultiFormatWriter damocles = new MultiFormatWriter();
        String contenido = leerContenidoArchivo(archivo, contexto);

        try {
            BitMatrix matriz = damocles.encode(contenido, BarcodeFormat.QR_CODE, 500, 500);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap mapa = encoder.createBitmap(matriz);

            // Convertir el Bitmap en formato JPEG
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            mapa.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] data =stream.toByteArray();
            guardarBitmapComoJPEG(stream, nombreArchivo,cloud,data);

            return mapa;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Código lector de textos
    private String leerContenidoArchivo(String archivo, Context contexto) {
        String contenido = "";

        try {
            AssetManager assetManager = contexto.getAssets();
            InputStream inputStream = assetManager.open(archivo);
            int tamanio = inputStream.available();
            byte[] buffer = new byte[tamanio];
            inputStream.read(buffer);
            inputStream.close();
            contenido = new String(buffer);

        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }

        return contenido;
    }


    private void guardarBitmapComoJPEG(ByteArrayOutputStream stream, String nombreArchivo,FirebaseStorage cloud,byte[] data) {

        StorageReference referencia;

        try {
            referencia = cloud.getReference();
            String QR = nombreArchivo + ".jpg";
            File file = new File(QR);
            StorageReference fire = referencia.child(file.getPath());
            UploadTask uploadTask = fire.putBytes(data);
            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {

                }

            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    taskSnapshot.getMetadata();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
