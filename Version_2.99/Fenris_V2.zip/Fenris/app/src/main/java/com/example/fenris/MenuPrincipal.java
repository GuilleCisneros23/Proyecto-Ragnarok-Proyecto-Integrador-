package com.example.fenris;

import java.util.List;

public class MenuPrincipal {

    private String NombreRestaurante;
    private int NumeroMesa;
    private List<Platillo> ListaDePlatillos;

    public MenuPrincipal(String nombreRestaurante, int numeroMesa, List<Platillo> listaDePlatillos) {
        NombreRestaurante = nombreRestaurante;
        NumeroMesa = numeroMesa;
        ListaDePlatillos = listaDePlatillos;
    }


    public String getNombreRestaurante() {
        return NombreRestaurante;
    }

    public void setNombreRestaurante(String nombreRestaurante) {
        NombreRestaurante = nombreRestaurante;
    }

    public int getNumeroMesa() {
        return NumeroMesa;
    }

    public void setNumeroMesa(int numeroMesa) {
        NumeroMesa = numeroMesa;
    }

    public List<Platillo> getListaDePlatillos() {
        return ListaDePlatillos;
    }

    public void setListaDePlatillos(List<Platillo> listaDePlatillos) {
        ListaDePlatillos = listaDePlatillos;
    }
}
