package com.example.fenris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class MenuRestaurante extends AppCompatActivity {

    String nombreUsuario;
    String QR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_restaurante);
        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intento = new Intent(getApplicationContext(), QRActivity.class);
        intento.putExtra("nombre_usuario", nombreUsuario);
        startActivity(intento);
        finish();
    }

}