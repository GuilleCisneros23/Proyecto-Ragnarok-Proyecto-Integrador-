package com.example.fenris;

public class Platillo {
    private int numMesa;
    private String Nombre;
    private String Descripcion;
    private String Instrucciones;
    private String Extra;
    private Double precio_e;
    public Double precio;

    public Platillo(int numMesa, String nombre, String descripcion, String instrucciones, String extra, Double precio_e, Double precio) {
        this.numMesa = numMesa;
        Nombre = nombre;
        Descripcion = descripcion;
        Instrucciones = instrucciones;
        Extra = extra;
        this.precio_e = precio_e;
        this.precio = precio;
    }



    public int getNumMesa() {
        return numMesa;
    }

    public void setNumMesa(int numMesa) {
        this.numMesa = numMesa;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getInstrucciones() {
        return Instrucciones;
    }

    public void setInstrucciones(String instrucciones) {
        Instrucciones = instrucciones;
    }

    public String getExtra() {
        return Extra;
    }

    public void setExtra(String extra) {
        Extra = extra;
    }

    public Double getPrecio_e() {
        return precio_e;
    }

    public void setPrecio_e(Double precio_e) {
        this.precio_e = precio_e;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
}
