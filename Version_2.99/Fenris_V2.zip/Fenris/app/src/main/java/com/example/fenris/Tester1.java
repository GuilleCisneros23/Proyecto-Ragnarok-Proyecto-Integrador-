package com.example.fenris;

public class Tester1 {

    public static void main(String[] args) {
        System.out.println("Hola, mundo desde Android Studio!");
    }
}
