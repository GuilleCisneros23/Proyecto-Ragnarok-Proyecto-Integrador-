package com.example.fenris;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.io.Serializable;

public class FragmentoPlatillo extends Fragment {

    private Bitmap cachedBitmap = null;

    public static FragmentoPlatillo newInstance(Platillo platillo) {
        FragmentoPlatillo fragment = new FragmentoPlatillo();
        Bundle args = new Bundle();
        args.putSerializable("platillo", (Serializable) platillo);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fragmento_platillo, container, false);

        TextView nombreTextView = view.findViewById(R.id.nombreTextView);
        ImageView imagen = view.findViewById(R.id.Plato);
        TextView precioTextView = view.findViewById(R.id.precioTextView);

        Platillo platillo = (Platillo) getArguments().getSerializable("platillo");
        String nombre = "Comida/" + platillo.getImagen() + ".jpg";

        if (cachedBitmap != null) {
            imagen.setImageBitmap(cachedBitmap);
        } else {
            StorageReference imagenComida = FirebaseStorage.getInstance().getReference().child(nombre);

            long MAXBYTES = 1024 * 1024;

            imagenComida.getBytes(MAXBYTES).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    Bitmap mapa = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    int w= 207;
                    int h= 197;
                    Bitmap seva = Bitmap.createScaledBitmap(mapa, w, h, true);
                    cachedBitmap = seva;
                    imagen.setImageBitmap(seva);
                    platillo.setJPG(cachedBitmap);
                }
            });
        }

        nombreTextView.setText(platillo.getIndice() + ". " + platillo.getNombrePlato());
        precioTextView.setText("$" + String.valueOf(platillo.getPrecio()));

        return view;
    }
}
