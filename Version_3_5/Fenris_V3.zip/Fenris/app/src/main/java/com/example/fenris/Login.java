package com.example.fenris;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Arrays;
import java.util.HashMap;

public class Login extends AppCompatActivity {

    TextInputEditText email, contraseña;
    Button Login;
    Button Registrarse;
    Button Google;
    Button Facebook;


    FirebaseUser usuario;
    FirebaseUser user;
    FirebaseAuth mAuth;
    FirebaseDatabase base;
    FirebaseStorage cloud;


    GoogleSignInClient cliente;
    int RC_SIGN_IN = 20;
    CallbackManager mCallbackManager;


    @Override
    public void onStart() {
        super.onStart();
        Inicio();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Inicio();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAuth.getCurrentUser() != null) {
            cliente.signOut();
            LoginManager.getInstance().logOut();
        }
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if (mAuth.getCurrentUser() != null) {
            mAuth.signOut();
            cliente.signOut();
            LoginManager.getInstance().logOut();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        Inicio();
    }

    @SuppressLint("WrongViewCast")
    public void Inicio() {
        email = findViewById(R.id.Correo);
        contraseña = findViewById(R.id.Contraseña);
        Login = findViewById(R.id.Login1);
        Registrarse = findViewById(R.id.Registrarse);
        Google = findViewById(R.id.botonGoogleLogin);
        Facebook = findViewById(R.id.botonFacebookLogin);

        mCallbackManager = CallbackManager.Factory.create();
        mAuth = FirebaseAuth.getInstance();
        base = FirebaseDatabase.getInstance();

        // Opciones para signin por medio de Google
        GoogleSignInOptions google = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("421550439239-6o3ro1nl5qg1so265opatlkf2pknoc9o.apps.googleusercontent.com")
                .requestEmail().build();
        cliente = GoogleSignIn.getClient(this, google);



        // Boton para hacer login con Google
        Google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginGoogle();
            }
        });



        // Boton para ir a actividad Registro
        Registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento = new Intent(getApplicationContext(), Registro.class);
                startActivity(intento);
                finish();
            }
        });



        // Boton para hacer login con correo y contraseña
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mail = email.getText().toString();
                String contra = contraseña.getText().toString();

                if (TextUtils.isEmpty(mail)) {
                    Toast.makeText(Login.this, "Escriba un correo válido", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(contra)) {
                    Toast.makeText(Login.this, "Escriba una contraseña válida", Toast.LENGTH_LONG).show();
                    return;
                }

                mAuth.signInWithEmailAndPassword(mail, contra)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Log.d(TAG, "signInWithEmail:success");
                                    user = mAuth.getCurrentUser();

                                    // Configura el nombre del usuario si está disponible
                                    String nombreUsuario = user.getDisplayName();

                                    if (TextUtils.isEmpty(nombreUsuario)) {
                                        nombreUsuario = mail;
                                    }
                                    Toast.makeText(Login.this, "Inicio de sesión exitoso...", Toast.LENGTH_SHORT).show();
                                    Intent intento1 = new Intent(getApplicationContext(), QRActivity.class);
                                    intento1.putExtra("nombre_usuario", nombreUsuario);
                                    startActivity(intento1);
                                    finish();
                                } else {
                                    Log.w(TAG, "signInWithEmail:failure", task.getException());
                                    Toast.makeText(Login.this, "Error de inicio de sesión...", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });



        Facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iniciarSesionFacebook();
            }
        });
    }

    //Funcion utilizada para la creacion del QR
    //Hecho en base al URL donde el archivo Mesa1(texto que tiene los datos) esta
    //Sirve como referencia para obtener el texto desde la base de Storage

    //public void QR(){
        //cloud = FirebaseStorage.getInstance();
        //StorageReference referencia = cloud.getReference();
        //String archivo = "Menus/Mesa1.txt";
        //String nombreArchivo = "QR";
        //StorageReference archivoRef = referencia.child(archivo);
        //archivoRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            //@Override
            //public void onSuccess(Uri uri) {
                //String archivoURL = uri.toString();
                //GeneradorDeCodigosQR generador = new GeneradorDeCodigosQR();
                //generador.QRs(archivoURL, nombreArchivo, cloud);
            //}
        //});
    //}


    private void loginGoogle() {
        Intent intento = cliente.getSignInIntent();
        startActivityForResult(intento, RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        mCallbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> tarea = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount cuenta = tarea.getResult(ApiException.class);
                firebaseAutenticacion(cuenta.getIdToken());
            } catch (Exception e) {
                Toast.makeText(this, "Inicio Fallido de sesión por medio de Google", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void firebaseAutenticacion(String idToken) {
        AuthCredential credenciales = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credenciales)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            usuario = mAuth.getCurrentUser();
                            String nombreUsuario = usuario.getDisplayName();
                            HashMap<String, Object> mapa = new HashMap<>();
                            mapa.put("ID", usuario.getUid());
                            mapa.put("Nombre", usuario.getDisplayName());
                            mapa.put("perfil", usuario.getPhotoUrl().toString());

                            base.getReference().child("Usuarios").child(usuario.getUid()).setValue(mapa);
                            Intent intento = new Intent(getApplicationContext(), QRActivity.class);
                            intento.putExtra("nombre_usuario", nombreUsuario);
                            startActivity(intento);
                        }
                    }
                });
    }

    private void iniciarSesionFacebook() {
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("email, public_profile"));
        LoginManager.getInstance().registerCallback(mCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d(TAG, "onSuccess:" + loginResult);
                handleFacebookAccessToken(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                Log.d(TAG, "onCancel");
            }

            @Override
            public void onError(FacebookException error) {
                Log.d(TAG, "onError", error);
            }
        });

    }

    private void handleFacebookAccessToken(AccessToken token) {
        Log.d(TAG, "handleFacebookAccessToken:" + token);
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            String nombreUsuario = user.getDisplayName();
                            Intent intento = new Intent(getApplicationContext(), QRActivity.class);
                            intento.putExtra("nombre_usuario", nombreUsuario);
                            startActivity(intento);

                        } else {
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                        }
                    }
                });
    }



}
