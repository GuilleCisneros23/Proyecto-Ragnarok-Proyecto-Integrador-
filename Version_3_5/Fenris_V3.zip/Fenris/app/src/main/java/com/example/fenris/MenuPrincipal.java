package com.example.fenris;

import java.util.List;

public class MenuPrincipal {

     String NombreRestaurante;
     String NumeroMesa;
     List<Platillo> ListaDePlatillos;
     String extras;

    public MenuPrincipal(String nombreRestaurante, String numeroMesa, List<Platillo> listaDePlatillos, String extras) {
        NombreRestaurante = nombreRestaurante;
        NumeroMesa = numeroMesa;
        ListaDePlatillos = listaDePlatillos;
        this.extras = extras;
    }

    public String getNombreRestaurante() {
        return NombreRestaurante;
    }

    public String getNumeroMesa() {
        return NumeroMesa;
    }

    public List<Platillo> getListaDePlatillos() {
        return ListaDePlatillos;
    }

    public String getExtras() {
        return extras;
    }
}
