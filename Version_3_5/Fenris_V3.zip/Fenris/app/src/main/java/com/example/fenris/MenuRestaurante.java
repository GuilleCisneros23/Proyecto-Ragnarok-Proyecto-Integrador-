package com.example.fenris;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MenuRestaurante extends AppCompatActivity {

    String nombreUsuario;
    String QR;
    TextView nombreRestaurante;
    TextView mesa;
    FirebaseStorage firebaseStorage;
    List<Platillo> platillos = new ArrayList<>();
    MenuPrincipal seva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_menu_restaurante);
        Main();
    }


    public void Main(){
        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");
        firebaseStorage = FirebaseStorage.getInstance();
        nombreRestaurante = findViewById(R.id.Restaurante);
        mesa = findViewById(R.id.Mesa);
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(QR);

        storageReference.getBytes(1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                String data = new String(bytes);
                seva = ProcesamientoQR(data);
                UIMenu();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception exception) {
                exception.printStackTrace();
            }
        });
    }



    public MenuPrincipal ProcesamientoQR(String line){

        Pattern pattern = Pattern.compile("\\[([^\\[\\]]+)\\]");
        Matcher matcher = pattern.matcher(line);

        while (matcher.find()) {
            // Obtiene el contenido entre los corchetes y lo imprime
            String texto= matcher.group(1);

            String []lines = texto.split("\n");
            String Nombre = lines[0].substring(lines[0].lastIndexOf(":") + 1);
            String mesa = lines[1].substring(lines[1].lastIndexOf(":") + 1);
            String extras = lines[2].substring(lines[2].lastIndexOf(":")+1);

            //Division del texto para almacenar cada uno de los platos
            String contenido = lines[3];
            String[] platos = contenido.split("-");

            //Creación de los platos individuales con sus respectivas caracteristicas
            for(int i=0;i<platos.length;i++){
                String platoIndividual = platos[i];
                String[]elementosPlato = platoIndividual.split("/");

                String Indice = elementosPlato[0].substring(elementosPlato[0].lastIndexOf(":")+1);
                String NombrePlato = elementosPlato[1].substring(elementosPlato[1].lastIndexOf(":")+1);
                String Descripcion = elementosPlato[2].substring(elementosPlato[2].lastIndexOf(":")+1);
                double Precio = Double.parseDouble(elementosPlato[3].substring(elementosPlato[3].lastIndexOf(":")+1));
                String Imagen = elementosPlato[4].substring(elementosPlato[4].lastIndexOf(":")+1);

                Platillo plato = new Platillo(Indice,NombrePlato,Descripcion,Precio,Imagen);
                platillos.add(plato);
            }
            seva = new MenuPrincipal(Nombre,mesa,platillos,extras);
        }
        return seva;
    }


    public void UIMenu() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        LinearLayout container = findViewById(R.id.fragmentContainer);
        nombreRestaurante.setText(seva.getNombreRestaurante());
        mesa.setText("Mesa: "+seva.getNumeroMesa());
        Fragment existingFragment = fragmentManager.findFragmentByTag("platilloFragmentTag");

        if (existingFragment != null) {
            return;
        }
        for (Platillo platillo : seva.getListaDePlatillos()) {
            FragmentoPlatillo platilloFragment = FragmentoPlatillo.newInstance(platillo);
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.add(container.getId(), platilloFragment, "platilloFragmentTag");
            transaction.commitAllowingStateLoss();
        }
    }




    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intento = new Intent(getApplicationContext(), QRActivity.class);
        intento.putExtra("nombre_usuario", nombreUsuario);
        startActivity(intento);
        finish();
    }
}
