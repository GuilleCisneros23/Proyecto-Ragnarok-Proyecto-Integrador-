package com.example.fenris;
import android.graphics.Bitmap;

import java.io.Serializable;
import java.util.Map;

public class Platillo implements Serializable {
    String Indice;
    String NombrePlato;
    String Descripcion;
    Double Precio;
    String Imagen;

    Bitmap JPG;

    public Platillo(String indice, String nombrePlato, String descripcion, Double precio, String imagen) {
        Indice = indice;
        NombrePlato = nombrePlato;
        Descripcion = descripcion;
        Precio = precio;
        Imagen = imagen;
        JPG = null;
    }

    public String getIndice() {
        return Indice;
    }
    public String getNombrePlato() {
        return NombrePlato;
    }

    public String getDescripcion() {
        return Descripcion;
    }
    public Double getPrecio() {
        return Precio;
    }
    public String getImagen() {
        return Imagen;
    }


    public Bitmap getJPG() {
        return JPG;
    }
    public void setJPG(Bitmap JPG) {
        this.JPG = JPG;
    }

}
