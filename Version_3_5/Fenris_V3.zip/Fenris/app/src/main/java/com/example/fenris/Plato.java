package com.example.fenris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Plato extends AppCompatActivity {

    TextView comida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plato);
        comida.findViewById(R.id.textView3);
        Intent intent = getIntent();

        if (intent != null) {
            Platillo platillo = (Platillo) intent.getSerializableExtra("platillo");

            if (platillo != null) {

                String jpg = platillo.getJPG().toString();
                comida.setText(jpg);

            }
        }
    }
}