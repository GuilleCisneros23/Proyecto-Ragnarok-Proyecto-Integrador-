package com.example.fenris;

import java.util.List;

public class MenuPrincipal {

     String NombreRestaurante;
     String NumeroMesa;
     List<Platillo> ListaDePlatillos;
     List<Platillo> Extras;
     List<Platillo> Bebidas;


    public MenuPrincipal(String nombreRestaurante, String numeroMesa, List<Platillo> listaDePlatillos,List<Platillo> extras, List<Platillo> bebidas ) {
        NombreRestaurante = nombreRestaurante;
        NumeroMesa = numeroMesa;
        ListaDePlatillos = listaDePlatillos;
        Extras = extras;
        Bebidas = bebidas;
    }

    public String getNombreRestaurante() {
        return NombreRestaurante;
    }

    public String getNumeroMesa() {
        return NumeroMesa;
    }

    public List<Platillo> getListaDePlatillos() {
        return ListaDePlatillos;
    }
    public List<Platillo> getListaDeExtras() {
        return Extras;
    }
    public List<Platillo> getListaDeBebidas() {
        return Bebidas;
    }
}
