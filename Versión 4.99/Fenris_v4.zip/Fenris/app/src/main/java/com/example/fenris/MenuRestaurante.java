package com.example.fenris;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MenuRestaurante extends AppCompatActivity {

    String nombreUsuario;
    String QR;
    TextView nombreRestaurante;
    TextView mesa;
    TextView cliente;
    FirebaseStorage firebaseStorage;


    List<Platillo> platillos = new ArrayList<>();
    List<Platillo> extra = new ArrayList<>();
    List<Platillo> bebida = new ArrayList<>();
    MenuPrincipal seva;


    RecyclerView recyclerView1;
    RecyclerView recyclerView2;
    RecyclerView recyclerView3;
    PlatilloAdaptador platilloAdapter1;
    PlatilloAdaptador platilloAdapter2;
    PlatilloAdaptador platilloAdapter3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_menu_restaurante);

        nombreRestaurante = findViewById(R.id.Restaurante);
        mesa = findViewById(R.id.Mesa);
        cliente = findViewById(R.id.Cliente);

        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");

        firebaseStorage = FirebaseStorage.getInstance();

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.submit(() -> {
            setLink(QR);
            new Handler(Looper.getMainLooper()).post(() -> {
                UIMenu(seva);
            });
        });
    }





        public void setLink(String codigo){
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(codigo);

        storageReference.getBytes(1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                String w = new String(bytes);
                seva = ProcesamientoQR(w);
                UIMenu(seva);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception exception) {
                    exception.printStackTrace();
                }
            });
    }


    public MenuPrincipal ProcesamientoQR(String line) {

        Pattern pattern = Pattern.compile("\\[([^\\[\\]]+)\\]");
        Matcher matcher = pattern.matcher(line);

        while (matcher.find()) {
            String texto= matcher.group(1);

            String []lines = texto.split("%");
            String Nombre = lines[0].substring(lines[0].lastIndexOf(":") + 1);
            String mesa = lines[1].substring(lines[1].lastIndexOf(":") + 1);
            String extras = lines[2].substring(lines[2].lastIndexOf("Extras{") + 1, lines[2].lastIndexOf("}"));
            String bebidas = lines[3].substring(lines[3].lastIndexOf("Bebidas(") + 1, lines[3].lastIndexOf(")"));
            String platos = lines[4].substring(lines[4].lastIndexOf("Platos<") + 1, lines[4].lastIndexOf(">"));;


            //Division para almacenar los Extras
            String[] e = extras.split("-");
            for(int i=0;i<e.length;i++){
                String platoIndividual = e[i];
                String[]elementosPlato = platoIndividual.split("/");

                String Indice = elementosPlato[0].substring(elementosPlato[0].lastIndexOf(":")+1);
                String NombrePlato = elementosPlato[1].substring(elementosPlato[1].lastIndexOf(":")+1);
                String Descripcion = elementosPlato[2].substring(elementosPlato[2].lastIndexOf(":")+1);
                double Precio = Double.parseDouble(elementosPlato[3].substring(elementosPlato[3].lastIndexOf(":")+1));
                String Imagen = elementosPlato[4].substring(elementosPlato[4].lastIndexOf(":")+1);

                Platillo plato = new Platillo(Indice,NombrePlato,Descripcion,Precio,Imagen);
                extra.add(plato);
            }


            //Division para almacenar las bebidas
            String[] b = bebidas.split("-");
            for(int i=0;i<b.length;i++){
                String platoIndividual = b[i];
                String[]elementosPlato = platoIndividual.split("/");

                String Indice = elementosPlato[0].substring(elementosPlato[0].lastIndexOf(":")+1);
                String NombrePlato = elementosPlato[1].substring(elementosPlato[1].lastIndexOf(":")+1);
                String Descripcion = elementosPlato[2].substring(elementosPlato[2].lastIndexOf(":")+1);
                double Precio = Double.parseDouble(elementosPlato[3].substring(elementosPlato[3].lastIndexOf(":")+1));
                String Imagen = elementosPlato[4].substring(elementosPlato[4].lastIndexOf(":")+1);

                Platillo plato = new Platillo(Indice,NombrePlato,Descripcion,Precio,Imagen);
                bebida.add(plato);
            }


            String[] p = platos.split("-");
            //Creación de los platos individuales con sus respectivas caracteristicas
            for(int i=0;i<p.length;i++){
                String platoIndividual = p[i];
                String[]elementosPlato = platoIndividual.split("/");

                String Indice = elementosPlato[0].substring(elementosPlato[0].lastIndexOf(":")+1);
                String NombrePlato = elementosPlato[1].substring(elementosPlato[1].lastIndexOf(":")+1);
                String Descripcion = elementosPlato[2].substring(elementosPlato[2].lastIndexOf(":")+1);
                double Precio = Double.parseDouble(elementosPlato[3].substring(elementosPlato[3].lastIndexOf(":")+1));
                String Imagen = elementosPlato[4].substring(elementosPlato[4].lastIndexOf(":")+1);

                Platillo plato = new Platillo(Indice,NombrePlato,Descripcion,Precio,Imagen);
                platillos.add(plato);
            }
            seva = new MenuPrincipal(Nombre,mesa,platillos,extra,bebida);
        }
        return seva;
    }

    public void UIMenu(MenuPrincipal seva) {
        if (seva != null) {
            nombreRestaurante.setText(seva.getNombreRestaurante());
            mesa.setText("Mesa: " + seva.getNumeroMesa());
            cliente.setText("Cliente: "+ nombreUsuario);

            List<Platillo> comidas = seva.getListaDePlatillos();;
            List<Platillo> extras = seva.getListaDeExtras();
            List<Platillo> bebidas = seva.getListaDeBebidas();


            recyclerView1 = findViewById(R.id.recyclerView);
            LinearLayoutManager manager1 = new LinearLayoutManager(getApplicationContext());
            recyclerView1.setLayoutManager(manager1);
            LinearLayout l1 = findViewById(R.id.l1);
            platilloAdapter1 = new PlatilloAdaptador(comidas,getApplicationContext());
            recyclerView1.setAdapter(platilloAdapter1);
            l1.setLayoutParams(recyclerView1.getLayoutParams());


            recyclerView2 = findViewById(R.id.recycleExtras);
            LinearLayoutManager manager2 = new LinearLayoutManager(getApplicationContext());
            recyclerView2.setLayoutManager(manager2);
            LinearLayout l2 = findViewById(R.id.l2);
            platilloAdapter2 = new PlatilloAdaptador(extras,getApplicationContext());
            recyclerView2.setAdapter(platilloAdapter2);
            l2.setLayoutParams(recyclerView2.getLayoutParams());


            recyclerView3 = findViewById(R.id.recycleBebidas);
            LinearLayoutManager manager3 = new LinearLayoutManager(getApplicationContext());
            recyclerView3.setLayoutManager(manager3);
            LinearLayout l3 = findViewById(R.id.l3);
            platilloAdapter3 = new PlatilloAdaptador(bebidas,getApplicationContext());
            recyclerView3.setAdapter(platilloAdapter3);
            l3.setLayoutParams(recyclerView3.getLayoutParams());


        } else {
        }
    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intento1 = new Intent(getApplicationContext(), QRActivity.class);
        intento1.putExtra("nombre_usuario", nombreUsuario);
        startActivity(intento1);
        finish();
    }


}

