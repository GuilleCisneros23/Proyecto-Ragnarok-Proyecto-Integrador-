package com.example.fenris;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.List;

public class PlatilloAdaptador extends RecyclerView.Adapter<PlatilloAdaptador.ViewHolder> {
    private List<Platillo> plato;
    private Context context; // Agregar variable de contexto

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView nombre;
        private final ImageView imagen;
        private final TextView precio;

        public ViewHolder(View view) {
            super(view);
            nombre = view.findViewById(R.id.nombreTextView);
            imagen = view.findViewById(R.id.Plato);
            precio = view.findViewById(R.id.precioTextView);
        }

        public TextView getNombre() {
            return nombre;
        }

        public ImageView getImagen() {
            return imagen;
        }

        public TextView getPrecio() {
            return precio;
        }
    }

    public PlatilloAdaptador(List<Platillo> p, Context context) {
        plato = p;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_plato, viewGroup, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        Platillo platillo = plato.get(position);
        String nombre = "Comida/" + platillo.getImagen() + ".jpg";
        StorageReference imagenComida = FirebaseStorage.getInstance().getReference().child(nombre);

        long MAXBYTES = 1024 * 1024;

        imagenComida.getBytes(MAXBYTES).addOnSuccessListener(bytes -> {
            Bitmap mapa = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            int w = 207;
            int h = 197;
            Bitmap seva = Bitmap.createScaledBitmap(mapa, w, h, true);
            viewHolder.getImagen().setImageBitmap(seva);
        });

        viewHolder.getNombre().setText("N°"+platillo.getIndice() + ". " + platillo.getNombrePlato());
        viewHolder.getPrecio().setText("$" + String.valueOf(platillo.getPrecio()));

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirActividadDetalles(plato.get(viewHolder.getAdapterPosition()));
            }
        });
    }


    private void abrirActividadDetalles(Platillo platillo) {
        Intent intent = new Intent(context, detallesPlato.class);
        intent.putExtra("plato", platillo);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }


    @Override
    public int getItemCount() {
        return plato.size();
    }
}
