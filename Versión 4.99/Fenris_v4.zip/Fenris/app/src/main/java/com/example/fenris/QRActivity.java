package com.example.fenris;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.camera.core.ExperimentalGetImage;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class QRActivity extends AppCompatActivity {
    Button regreso;
    TextView introduccion;
    TextView qr_traducido;
    String nombreUsuario;
    PreviewView previewView;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 100;
    private Executor cameraExecutor = Executors.newSingleThreadExecutor();
    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        initializeActivity();
        initCamera();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!hasCameraPermission()) {
            requestCameraPermission();
        } else {
            initializeActivity();
            initCamera();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        initializeActivity();
        initCamera();
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();
    }


    private void initializeActivity() {
        introduccion = findViewById(R.id.Instrucciones);
        regreso = findViewById(R.id.Regreso);
        previewView = findViewById(R.id.Camara);
        nombreUsuario = getIntent().getStringExtra("nombre_usuario");

        if (nombreUsuario != null) {
            introduccion.setText("Bienvenido, " + nombreUsuario + ", a la aplicación Seva! " +
                    "para continuar necesitas leer el QR en tu mesa para acceder " +
                    "al menú del establecimiento...");
        }

        regreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento = new Intent(getApplicationContext(), Login.class);
                startActivity(intento);
                finish();
            }
        });

        if (hasCameraPermission()) {
            initCamera();
        } else {
            requestCameraPermission();
        }
    }



    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }



    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST_CODE);
    }




    private void initCamera() {
        cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

                int rotation = getWindowManager().getDefaultDisplay().getRotation();
                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder().setTargetRotation(rotation).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                imageAnalysis.setAnalyzer(cameraExecutor, new ImageAnalysis.Analyzer() {
                    @OptIn(markerClass = ExperimentalGetImage.class)
                    @Override
                    public void analyze(ImageProxy imageProxy) {
                        Image mediaImage = imageProxy.getImage();
                        if (mediaImage != null) {
                            InputImage image = InputImage.fromMediaImage(mediaImage, imageProxy.getImageInfo().getRotationDegrees());

                            BarcodeScanner scanner = BarcodeScanning.getClient();

                            scanner.process(image)
                                    .addOnSuccessListener(barcodes -> {
                                        for (Barcode barcode : barcodes) {
                                            String URL = barcode.getRawValue();
                                            Intent menu = new Intent(getApplicationContext(), MenuRestaurante.class);
                                            menu.putExtra("QR",URL);
                                            menu.putExtra("nombre_usuario", nombreUsuario);
                                            startActivity(menu);
                                        }
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(getApplicationContext(), "Escaneo fallido, inténtelo de nuevo.", Toast.LENGTH_SHORT).show();
                                    })
                                    .addOnCompleteListener(task -> imageProxy.close());
                        }
                    }
                });

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);
            } catch (ExecutionException | InterruptedException e) {
                Log.e("CameraX", "Error al iniciar la cámara", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }



    private void releaseCamera() {
        if (cameraProviderFuture != null && cameraProviderFuture.isDone()) {
            ProcessCameraProvider cameraProvider;
            try {
                cameraProvider = cameraProviderFuture.get();
            } catch (ExecutionException | InterruptedException e) {
                Log.e("CameraX", "Error al obtener el proveedor de la cámara", e);
                return;
            }

            cameraProvider.unbindAll();
        }
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initCamera();
            } else {
                Toast.makeText(getApplicationContext(), "La aplicación necesita permiso para acceder a la cámara.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
