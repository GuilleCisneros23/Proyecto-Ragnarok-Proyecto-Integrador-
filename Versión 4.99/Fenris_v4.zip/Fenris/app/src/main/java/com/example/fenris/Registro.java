package com.example.fenris;

import static android.content.ContentValues.TAG;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class Registro extends AppCompatActivity {

    FirebaseAuth mAuth;
    TextInputEditText email, contraseña, usuario;
    Button Registrarse;
    Button Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_registro);
        mAuth = FirebaseAuth.getInstance();
        usuario = findViewById(R.id.Usuario);
        email = findViewById(R.id.Correo);
        contraseña = findViewById(R.id.Contraseña);
        Registrarse = findViewById(R.id.BotonRegistroMail);
        Login = findViewById(R.id.Login2);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento = new Intent(getApplicationContext(), Login.class);
                startActivity(intento);
                finish();
            }
        });

        Registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String nombre = usuario.getText().toString();
                final String mail = email.getText().toString();
                final String contra = contraseña.getText().toString();

                if (TextUtils.isEmpty(mail) || TextUtils.isEmpty(contra) || TextUtils.isEmpty(nombre)) {
                    Toast.makeText(Registro.this, "Por favor, complete todos los campos.", Toast.LENGTH_LONG).show();
                    return;
                }

                mAuth.createUserWithEmailAndPassword(mail, contra)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    String userID = user.getUid();

                                    // Guardar el nombre de usuario en Firebase Realtime Database
                                    DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("usuarios");
                                    Map<String, Object> userData = new HashMap<>();
                                    userData.put("nombre", nombre);
                                    databaseRef.child(userID).setValue(userData);

                                    // Establecer el nombre de usuario en el perfil del usuario en Firebase Authentication
                                    UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder().setDisplayName(nombre).build();
                                    user.updateProfile(profileUpdates);

                                    Log.d(TAG, "createUserWithEmail:success");
                                    Toast.makeText(Registro.this, "Cuenta registrada...", Toast.LENGTH_SHORT).show();

                                    Intent intento = new Intent(getApplicationContext(), Login.class);
                                    startActivity(intento);
                                    finish();
                                } else {
                                    // Si la creación de la cuenta falla, muestra un mensaje de error
                                    Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(Registro.this, "Error al registrar cuenta...", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }
}
