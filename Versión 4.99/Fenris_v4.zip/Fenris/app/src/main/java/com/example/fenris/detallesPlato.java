package com.example.fenris;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class detallesPlato extends AppCompatActivity {
    TextView name;
    TextView descripcion;
    TextView cantidad;
    ImageView imagen;


    Button precio;
    Button añadir;
    Button reducir;

    int qta = 1;
    double total = 0;
    Platillo plato;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_plato);
        getSupportActionBar().hide();

        Intent intent = getIntent();
        plato = (Platillo) intent.getSerializableExtra("plato");
        Ventana(plato);
    }

    public void Ventana(Platillo plato){
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Cargando Platillo...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        name = findViewById(R.id.nombre);
        descripcion = findViewById(R.id.descripcion);
        precio = findViewById(R.id.precio);
        imagen = findViewById(R.id.imagen);

        String nombre = "Comida/" + plato.getImagen() + ".jpg";
        StorageReference imagenComida = FirebaseStorage.getInstance().getReference().child(nombre);

        long MAXBYTES = 1024 * 1024;

        imagenComida.getBytes(MAXBYTES).addOnSuccessListener(bytes -> {
            Bitmap mapa = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            int w = 500;
            int h = 500;
            Bitmap seva = Bitmap.createScaledBitmap(mapa, w, h, true);
            imagen.setImageBitmap(seva);
            name.setText(plato.getNombrePlato()+"  -  $"+plato.getPrecio());
            descripcion.setText(plato.getDescripcion());
            total = plato.getPrecio();
            String t = String.format("%.2f", total);
            precio.setText("Agregar "+String.valueOf(qta)+" por $" + t);
            Botones();

            progressDialog.dismiss();
        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
        });
    }

    public void Botones(){
        cantidad = findViewById(R.id.textViewValor);
        añadir = findViewById(R.id.btnINC);
        reducir = findViewById(R.id.btnDEC);

        añadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incrementarValor();
            }
        });

        reducir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decrementarValor();
            }
        });

    }

    private void incrementarValor() {
        qta++;
        total = total + plato.getPrecio();
        actualizarPrecio();
    }

    private void decrementarValor() {
        if (qta > 1){
            qta--;
            total = total - plato.getPrecio();
            actualizarPrecio();
        }
    }

    private void actualizarPrecio() {
        cantidad.setText(String.valueOf(qta));
        String t = String.format("%.2f", total);
        precio.setText("Agregar "+String.valueOf(qta)+" por $" + t);
    }

}
