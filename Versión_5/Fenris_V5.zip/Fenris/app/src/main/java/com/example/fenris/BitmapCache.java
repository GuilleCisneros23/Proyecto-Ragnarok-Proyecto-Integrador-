package com.example.fenris;

import android.graphics.Bitmap;

import java.util.HashMap;

public class BitmapCache {
    private static HashMap<String, Bitmap> bitmapHashMap = new HashMap<>();

    public static void addToCache(String key, Bitmap bitmap) {
        bitmapHashMap.put(key, bitmap);
    }

    public static Bitmap getFromCache(String key) {
        return bitmapHashMap.get(key);
    }

    public static void removeFromCache(String key) {
        bitmapHashMap.remove(key);
    }
}
