package com.example.fenris;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CheckOut extends AppCompatActivity implements CheckoutAdaptador.OnItemClickListener,CheckoutAdaptador.OnCartEmptyListener,CheckoutAdaptador.OnFragmentDestroyListener{

    TextView restaurante;
    TextView Orden;
    TextView subtotal;
    TextView iva;
    TextView servicio;
    TextView total;

    RecyclerView platos;
    Button boton;
    Button actualizar;


    String QR;
    String nombreUsuario;
    Order Elden;


    double precio=0;
    double precioIva = 0;
    double serv = 2;
    double precioTotal = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);
        getSupportActionBar().hide();


        restaurante = findViewById(R.id.Restaurante);
        Orden = findViewById(R.id.PlatosOrden);
        subtotal = findViewById(R.id.ValorSubtotal);
        iva = findViewById(R.id.ValorIVA);
        servicio = findViewById(R.id.ValorServicio);
        total = findViewById(R.id.ValorTotal);
        platos = findViewById(R.id.recyclerSubtotal);
        boton = findViewById(R.id.b);
        actualizar = findViewById(R.id.actualizar);


        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");
        Elden = (Order) getIntent().getSerializableExtra("Order");
        restaurante.setText("Checkout"+" ("+Elden.getNombreRestaurante()+")");
        Orden.setText("Orden - Mesa:"+Elden.getNumeroMesa());
        Subtotal(Elden);


        LinearLayout l1 = findViewById(R.id.lFinal);
        LinearLayoutManager m = new LinearLayoutManager(getApplicationContext());
        platos.setLayoutManager(m);
        CheckoutAdaptador adaptador = new CheckoutAdaptador(Elden.getOrdenes(), getApplicationContext());
        adaptador.setOnItemClickListener(this);
        adaptador.setOnCartEmptyListener(this);
        adaptador.setOnFragmentDestroyListener(this);
        platos.setAdapter(adaptador);
        l1.setLayoutParams(platos.getLayoutParams());



        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento1 = new Intent(getApplicationContext(), MenuRestaurante.class);
                intento1.putExtra("nombre_usuario", nombreUsuario);
                intento1.putExtra("QR", QR);
                intento1.putExtra("Orden", Elden);
                setResult(RESULT_OK, intento1);
                finish();
            }
        });


        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Subtotal(Elden);
            }
        });


    }



    public void Subtotal(Order orden){
        precio=calcularSumaPrecios(orden.getOrdenes());
        precioIva = precio * orden.getImpuestos();
        precioTotal = precio + precioIva + serv;
        String sub = String.format("%.2f",precio);
        String precioIVA = String.format("%.2f",precioIva);
        String precioServicio = String.format("%.2f",serv);
        String T= String.format("%.2f",precioTotal);
        subtotal.setText("$"+ sub);
        iva.setText("$"+ precioIVA);
        servicio.setText("$"+precioServicio);
        total.setText("$"+T);
    }



    public double calcularSumaPrecios(List<OrderItem> orderItems) {
        double sumaPrecios = 0.0;
        for (OrderItem item : orderItems) {
            sumaPrecios += item.getPrecio();
        }
        return sumaPrecios;
    }


    @Override
    public void onItemClick(List<OrderItem>l) {
        Elden.setOrdenes(l);
    }



    @Override
    public void onCartEmptied() {
        Intent intent = new Intent(getApplicationContext(), MenuRestaurante.class);
        intent.putExtra("nombre_usuario", nombreUsuario);
        intent.putExtra("QR", QR);
        intent.putExtra("Vacio", Elden);
        setResult(RESULT_OK, intent);
        finish();
    }


    @Override
    public void onDestroyFragment(List<OrderItem>l) {
        Elden.setOrdenes(l);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intento1 = new Intent(getApplicationContext(), MenuRestaurante.class);
        intento1.putExtra("nombre_usuario", nombreUsuario);
        intento1.putExtra("QR", QR);
        intento1.putExtra("Orden", Elden);
        setResult(RESULT_OK, intento1);
        finish();
    }

}