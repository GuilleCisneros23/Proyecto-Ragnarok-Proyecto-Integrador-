package com.example.fenris;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.List;

public class CheckoutAdaptador extends RecyclerView.Adapter<CheckoutAdaptador.ViewHolder> {

    private List<OrderItem> lista;
    private Context context;
    private OrderItem item;

    int qta = 1;
    double total = 0.0;




    public CheckoutAdaptador(List<OrderItem> lista, Context context) {
        this.lista = lista;
        this.context = context;
    }




    //Caso para alterar las cantidades de los platos
    public interface OnItemClickListener { void onItemClick(List<OrderItem> lista);}
    private OnItemClickListener Alistener;
    public void setOnItemClickListener(OnItemClickListener listener) {Alistener = listener;}

    ////////////////////////////////////////////////////////////////////////////////////////

    //Caso en el que se elimina un plato de la Orden
    public interface OnFragmentDestroyListener { void onDestroyFragment(List<OrderItem> lista);}
    private OnFragmentDestroyListener destroyListener;
    public void setOnFragmentDestroyListener(OnFragmentDestroyListener listener){this.destroyListener = listener;}

    //////////////////////////////////////////////////////////////////////////////////////////

    //Caso en el que el carrito se vacia por completo
    public interface OnCartEmptyListener { void onCartEmptied();}
    private OnCartEmptyListener cartEmptyListener;
    public void setOnCartEmptyListener(OnCartEmptyListener listener) {this.cartEmptyListener = listener;}




    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView nombre;
        private final TextView instrucciones;
        private final TextView precio;
        private final TextView cantidad;

        ImageView imagen;
        private Button aumentar;
        private Button restar;


        public ViewHolder(View view) {
            super(view);
            nombre = view.findViewById(R.id.nombrePlatoSubtotal);
            instrucciones = view.findViewById(R.id.instruccionesSubtotal);
            precio = view.findViewById(R.id.precioSubtotal);
            cantidad = view.findViewById(R.id.CantidadSubvalor);
            aumentar = view.findViewById(R.id.btnINCSubtotal);
            restar = view.findViewById(R.id.btnDECSubtotal);
            imagen = view.findViewById(R.id.imagenSubtotal);
        }

        public TextView getNombre() {
            return nombre;
        }

        public TextView getPrecio() {
            return precio;
        }

        public TextView getInstrucciones() {
            return instrucciones;
        }

        public Button getAumentar() {
            return aumentar;
        }

        public Button getRestar() {
            return restar;
        }

        public TextView getCantidad() {
            return cantidad;
        }

        public ImageView getImagen() {
            return imagen;
        }

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_sublista_checkout, viewGroup, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder viewHolder, @SuppressLint("RecyclerView") int position) {
        item = lista.get(position);
        String nombre = "Comida/" + item.getJPG() + ".jpg";
        StorageReference imagenComida = FirebaseStorage.getInstance().getReference().child(nombre);
        viewHolder.getCantidad().setText(String.valueOf(item.getCantidad()));

        long MAXBYTES = 1024 * 1024;

        imagenComida.getBytes(MAXBYTES).addOnSuccessListener(bytes -> {
            Bitmap mapa = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            int targetW = viewHolder.getImagen().getWidth();
            int targetH = viewHolder.getImagen().getHeight();
            Bitmap seva = Bitmap.createScaledBitmap(mapa, targetW, targetH, true);
            viewHolder.getImagen().setImageBitmap(seva);
        });

        if (item.getInstrucciones() == null) {
            item.setInstrucciones("Sin indicaciones especiales...");
            viewHolder.getNombre().setText(String.valueOf(item.getCantidad()) + " X " + item.getNombrePlato());
            viewHolder.getInstrucciones().setText(item.getInstrucciones());
            String t = String.format("%.2f", item.getPrecio());
            viewHolder.getPrecio().setText("$" + t);
        } else {
            viewHolder.getNombre().setText(String.valueOf(item.getCantidad()) + " X " + item.getNombrePlato());
            viewHolder.getInstrucciones().setText(item.getInstrucciones());
            String t = String.format("%.2f", item.getPrecio());
            viewHolder.getPrecio().setText("$" + t);
        }

        viewHolder.getAumentar().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Alistener != null) {
                    Alistener.onItemClick(lista);
                    incrementarValor(position);
                    notifyDataSetChanged();
                }
            }
        });

        viewHolder.getRestar().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Alistener != null) {
                    Alistener.onItemClick(lista);
                    decrementarValor(position);
                    notifyDataSetChanged();
                }
            }
        });

    }


    private void incrementarValor(int position) {
        item = lista.get(position);
        qta = item.getCantidad();
        double precioUnitario = item.getPrecio() / qta;
        qta++;
        item.setCantidad(qta);
        item.setPrecio(qta * precioUnitario);
        lista.set(position, item);
        notifyDataSetChanged();
    }




    private void decrementarValor(int position) {
        item = lista.get(position);
        qta = item.getCantidad();

        if (qta >= 1) {
            double precioUnitario = item.getPrecio() / qta;
            qta--;
            item.setCantidad(qta);
            item.setPrecio(qta * precioUnitario);
            lista.set(position, item);
            notifyDataSetChanged();
        }

        if (qta == 0) {

            if (destroyListener != null) {
                lista.get(position).setPrecio(0.0);
                lista.get(position).setCantidad(0);
                lista.remove(position);
                destroyListener.onDestroyFragment(lista);
            }

            if (lista.isEmpty()) {
                if (cartEmptyListener != null) {
                    cartEmptyListener.onCartEmptied();
                }
            }
        }
    }



    @Override
    public int getItemCount() {
        return lista.size();
    }

}
