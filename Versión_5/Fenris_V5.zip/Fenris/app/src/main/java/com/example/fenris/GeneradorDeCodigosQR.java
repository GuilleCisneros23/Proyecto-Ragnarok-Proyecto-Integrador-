package com.example.fenris;
import android.graphics.Bitmap;
import android.net.Uri;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import java.io.ByteArrayOutputStream;

public class GeneradorDeCodigosQR {

    public void QRs(String link, String nombreArchivo, FirebaseStorage cloud) {
        try {
            MultiFormatWriter damocles = new MultiFormatWriter();
            BitMatrix matriz = damocles.encode(link, BarcodeFormat.QR_CODE, 500, 500);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap mapa = encoder.createBitmap(matriz);

            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            mapa.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] data = stream.toByteArray();

            guardarBitmapComoJPEG(nombreArchivo, cloud, data);

        } catch (WriterException e) {
            e.printStackTrace();
            // Manejar la excepción de manera adecuada
        }
    }

    private void guardarBitmapComoJPEG(String nombreArchivo, FirebaseStorage cloud, byte[] data) {
        StorageReference referencia = cloud.getReference(nombreArchivo + ".jpg");
        UploadTask uploadTask = referencia.putBytes(data);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception exception) {
                exception.printStackTrace();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
    }
}
