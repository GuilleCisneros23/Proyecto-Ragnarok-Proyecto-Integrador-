package com.example.fenris;

import java.util.List;

public class Order extends MenuPrincipal {

    private String cliente;
    private List<OrderItem> ordenes;
    private Double impuestos;
    private Double precioTotal;


    public Order(String cliente, String nombreRestaurante, String numeroMesa, List<OrderItem>ordenes, Double impuestos, Double precioTotal) {
        super(nombreRestaurante, numeroMesa);
        this.cliente=cliente;
        this.ordenes=ordenes;
        this.impuestos=impuestos;
        this.precioTotal=precioTotal;
    }

    public Order(String cliente, String nombreRestaurante, String numeroMesa,Double impuestos) {
        super(nombreRestaurante, numeroMesa);
        this.cliente=cliente;
        this.impuestos=impuestos;
    }


    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public List<OrderItem> getOrdenes() {
        return ordenes;
    }

    public void setOrdenes(List<OrderItem> ordenes) {
        this.ordenes = ordenes;
    }

    public Double getImpuestos() {
        return impuestos;
    }

    public void setImpuestos(Double impuestos) {
        this.impuestos = impuestos;
    }

    public Double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(Double precioTotal) {
        this.precioTotal = precioTotal;
    }
}
