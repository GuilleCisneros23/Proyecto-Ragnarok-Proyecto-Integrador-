package com.example.fenris;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.Map;

public class Platillo implements Serializable {
    private String Indice;
    private String NombrePlato;
    private String Descripcion;
    private Double Precio;
    private String Imagen;

    private Bitmap jpg;

    public Platillo(String indice, String nombrePlato, String descripcion, Double precio, String imagen) {
        Indice = indice;
        NombrePlato = nombrePlato;
        Descripcion = descripcion;
        Precio = precio;
        Imagen = imagen;
    }

    public String getIndice() {
        return Indice;
    }
    public String getNombrePlato() {
        return NombrePlato;
    }

    public String getDescripcion() {
        return Descripcion;
    }
    public Double getPrecio() {
        return Precio;
    }
    public String getImagen() {
        return Imagen;
    }

    public void setIndice(String indice) {
        Indice = indice;
    }

    public void setNombrePlato(String nombrePlato) {
        NombrePlato = nombrePlato;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public void setPrecio(Double precio) {
        Precio = precio;
    }

    public void setImagen(String imagen) {
        Imagen = imagen;
    }


    public Bitmap getJpg() {
        return jpg;
    }

    public void setJpg(Bitmap jpg) {
        this.jpg = jpg;
    }

}
