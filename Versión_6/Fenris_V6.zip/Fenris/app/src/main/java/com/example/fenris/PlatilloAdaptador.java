package com.example.fenris;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PlatilloAdaptador extends RecyclerView.Adapter<PlatilloAdaptador.ViewHolder> {
    private List<Platillo> plato;
    private String QR;
    private String nombre;
    private Context context;

    private int q=0;

    String term = "\\s*#\\d+\\.\\s*";


    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView nombre;
        private final ImageView imagen;
        private final TextView precio;

        public ViewHolder(View view) {
            super(view);
            nombre = view.findViewById(R.id.nombreTextView);
            imagen = view.findViewById(R.id.Plato);
            precio = view.findViewById(R.id.precioTextView);
        }

        public TextView getNombre() {
            return nombre;
        }

        public ImageView getImagen() {
            return imagen;
        }

        public TextView getPrecio() {
            return precio;
        }
    }



    public interface OnPlatoClickListener {
        void onPlatoClick(Platillo plato);
    }



    private OnPlatoClickListener mListener;

    public PlatilloAdaptador(int q,List<Platillo> p, Context context, String QR, String n,OnPlatoClickListener listener) {
        this.q = q;
        plato = p;
        this.context = context;
        this.QR=QR;
        nombre=n;
        this.mListener = listener;
    }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_plato, viewGroup, false);
        return new ViewHolder(view);
    }



    public void actualizarNumero(String indice, int cantidad, List<Platillo> plato) {
        if (cantidad == 0) {
            for (Platillo platillo : plato) {
                platillo.setNombrePlato(platillo.getNombrePlato().replaceAll(term, ""));
            }
        } else {
            for (Platillo platillo : plato) {
                if (platillo.getIndice().equals(indice)) {
                    int cantidadActual = obtenerCantidadDelNombre(platillo.getNombrePlato());
                    int nuevaCantidad = cantidadActual + cantidad;

                    if (nuevaCantidad == 0) {
                        platillo.setNombrePlato(platillo.getNombrePlato().replaceAll(term, ""));
                    } else {
                        platillo.setNombrePlato(platillo.getNombrePlato().replaceAll(term, "") + " #" + nuevaCantidad + ".");
                    }
                    notifyItemChanged(plato.indexOf(platillo));
                }
            }
        }
    }

    public void actualizarCheckout(List<OrderItem> orderItems, List<Platillo> platos) {
        for (Platillo platillo : platos) {
            boolean encontrado = false;
            for (OrderItem orderItem : orderItems) {
                if (orderItem.getIndice().equals(platillo.getIndice())) {
                    int nuevaCantidad = orderItem.getCantidad();

                    if (nuevaCantidad <= 0) {
                        platillo.setNombrePlato(platillo.getNombrePlato().replaceAll(term, ""));
                    } else {
                        platillo.setNombrePlato(platillo.getNombrePlato().replaceAll(term, "") + " #" + nuevaCantidad + ".");
                    }
                    notifyItemChanged(platos.indexOf(platillo));
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                platillo.setNombrePlato(platillo.getNombrePlato().replaceAll(term, ""));
                notifyItemChanged(platos.indexOf(platillo));
            }
        }
    }

    private int obtenerCantidadDelNombre(String nombrePlato) {
        Pattern pattern = Pattern.compile("#(\\d+)\\.");
        Matcher matcher = pattern.matcher(nombrePlato);

        if (matcher.find()) {
            return Integer.parseInt(matcher.group(1));
        }
        return 0;
    }




    @Override
    public void onBindViewHolder(ViewHolder viewHolder,  int position) {
        Platillo platillo = plato.get(position);
        String nombre = "Comida/" + platillo.getImagen() + ".jpg";
        StorageReference imagenComida = FirebaseStorage.getInstance().getReference().child(nombre);

        long MAXBYTES = 1024 * 1024;

        imagenComida.getBytes(MAXBYTES).addOnSuccessListener(bytes -> {
            Bitmap mapa = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            int w = 207;
            int h = 197;
            Bitmap seva = Bitmap.createScaledBitmap(mapa, w, h, true);
            viewHolder.getImagen().setImageBitmap(seva);
        });


        viewHolder.getPrecio().setText("$" + String.valueOf(platillo.getPrecio()));
        viewHolder.getNombre().setText("N°" + platillo.getIndice() + ". " + platillo.getNombrePlato());

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onPlatoClick(platillo); // Utilizar el platillo original
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return plato.size();
    }
}
