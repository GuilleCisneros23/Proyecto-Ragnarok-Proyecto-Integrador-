package com.example.fenris;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResumenOrden extends AppCompatActivity {

    Button regreso;
    TextView rewatch;
    String QR;
    String nombreUsuario;
    String Resumen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_resumen_orden);
        regreso = findViewById(R.id.RegresoMenu);
        rewatch = findViewById(R.id.Resumen);

        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");
        Resumen = getIntent().getStringExtra("Resumen");
        rewatch.setText(Resumen);


        regreso.setOnClickListener(new View.OnClickListener() {@Override
            public void onClick(View view) {
            Intent intent = new Intent(getApplicationContext(), MenuRestaurante.class);
            intent.putExtra("nombre_usuario", nombreUsuario);
            intent.putExtra("QR", QR);
            startActivity(intent);
            }
        });

    }
}