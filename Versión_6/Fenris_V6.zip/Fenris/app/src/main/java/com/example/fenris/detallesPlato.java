package com.example.fenris;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class detallesPlato extends AppCompatActivity {
    TextView name;
    TextView descripcion;
    TextInputEditText instrucciones;
    TextView cantidad;
    ImageView imagen;

    Button precio;
    Button añadir;
    Button reducir;

    int qta = 1;
    double total = 0;
    OrderItem item;

    Platillo plato;
    String QR;
    String nombre;
    String textoEscrito = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_plato);
        getSupportActionBar().hide();

        Intent intent = getIntent();
        QR = intent.getStringExtra("QR");
        nombre = intent.getStringExtra("nombre_usuario");
        plato = (Platillo) intent.getSerializableExtra("plato");
        String c = obtenerNombreOriginal(plato.getNombrePlato());
        plato.setNombrePlato(c);
        Ventana(plato);
    }

    private String obtenerNombreOriginal(String nombrePlatoConCantidad) {
        String nombreOriginal = nombrePlatoConCantidad.replaceAll("\\s*#\\d+\\.\\s*", "");
        return nombreOriginal.trim();
    }


    public void Ventana(Platillo plato){
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Cargando Platillo...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        name = findViewById(R.id.nombre);
        descripcion = findViewById(R.id.descripcion);
        instrucciones = findViewById(R.id.Instrucciones);
        precio = findViewById(R.id.precio);
        imagen = findViewById(R.id.imagen);

        String nombre = "Comida/" + plato.getImagen() + ".jpg";
        StorageReference imagenComida = FirebaseStorage.getInstance().getReference().child(nombre);

        long MAXBYTES = 1024 * 1024;

        imagenComida.getBytes(MAXBYTES).addOnSuccessListener(bytes -> {
            Bitmap mapa = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            int w = 500;
            int h = 500;
            Bitmap seva = Bitmap.createScaledBitmap(mapa, w, h, true);
            imagen.setImageBitmap(seva);
            name.setText(plato.getNombrePlato()+"  -  $"+plato.getPrecio());
            descripcion.setText(plato.getDescripcion());
            total = plato.getPrecio();
            String t = String.format("%.2f", total);
            precio.setText("Agregar "+String.valueOf(qta)+" por $" + t);

            instrucciones.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    textoEscrito = charSequence.toString();
                }

                @Override
                public void afterTextChanged(Editable editable) {
                }
            });


            String textoInstrucciones = obtenerTextoInstrucciones();

            item = new OrderItem(qta, plato.getIndice(), plato.getNombrePlato(), plato.getDescripcion(), textoInstrucciones, total, plato.getImagen());

            Botones();
            progressDialog.dismiss();
        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
        });
    }

    public void Botones(){
        cantidad = findViewById(R.id.textViewValor);
        añadir = findViewById(R.id.btnINC);
        reducir = findViewById(R.id.btnDEC);

        añadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incrementarValor();
            }
        });

        reducir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decrementarValor();
            }
        });

        precio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actualizarItem();
                Intent intent = new Intent(getApplicationContext(), MenuRestaurante.class);
                intent.putExtra("Orden", item);
                intent.putExtra("nombre_usuario", nombre);
                intent.putExtra("QR", QR);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

    }

    private String obtenerTextoInstrucciones() {
        if (instrucciones != null) {
            return instrucciones.getText().toString();
        } else {
            return "";
        }
    }

    private void incrementarValor() {
        qta++;
        total = total + plato.getPrecio();
        item.setCantidad(qta);
        item.setPrecio(total);
        actualizarPrecio();
    }

    private void decrementarValor() {
        if (qta > 1){
            qta--;
            total = total - plato.getPrecio();
            item.setCantidad(qta);
            item.setPrecio(total);
            actualizarPrecio();
        }
    }
    private void actualizarPrecio() {
        cantidad.setText(String.valueOf(item.getCantidad()));
        String t = String.format("%.2f", item.getPrecio());
        precio.setText("Agregar "+String.valueOf(item.getCantidad())+" por $" + t);
    }

    private void actualizarItem() {
        String textoInstrucciones = obtenerTextoInstrucciones();
        item = new OrderItem(qta, plato.getIndice(), plato.getNombrePlato(), plato.getDescripcion(), textoInstrucciones, total, plato.getImagen());
    }

}
