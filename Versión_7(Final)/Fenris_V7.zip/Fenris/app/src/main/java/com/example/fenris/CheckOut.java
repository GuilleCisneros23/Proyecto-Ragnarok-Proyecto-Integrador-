package com.example.fenris;
import android.Manifest;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.paypal.checkout.createorder.CreateOrderActions;
import com.paypal.checkout.createorder.CurrencyCode;
import com.paypal.checkout.createorder.OrderIntent;
import com.paypal.checkout.createorder.UserAction;
import com.paypal.checkout.order.Amount;
import com.paypal.checkout.order.AppContext;
import com.paypal.checkout.order.OrderRequest;
import com.paypal.checkout.order.PurchaseUnit;
import com.paypal.checkout.paymentbutton.PaymentButtonContainer;

import java.util.ArrayList;
import java.util.List;


public class CheckOut extends AppCompatActivity implements CheckoutAdaptador.OnItemClickListener,CheckoutAdaptador.OnCartEmptyListener,CheckoutAdaptador.OnFragmentDestroyListener{
    TextView Orden;
    TextView subtotal;
    TextView iva;
    TextView servicio;
    TextView total;


    RecyclerView platos;
    Button regresar;
    Button actualizar;
    Button pagos;
    Spinner metodos;
    Spinner factura;


    String QR;
    String nombreUsuario;
    Order Elden;


    List<OrderItem> lista = new ArrayList<>();
    List<ItemSpinner> m = new ArrayList<>();
    List<ItemSpinner> f = new ArrayList<>();


    double precio=0;
    double precioIva = 0;
    double serv = 0;
    double precioTotal = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);
        getSupportActionBar().hide();

        Orden = findViewById(R.id.Subtitulo);
        subtotal = findViewById(R.id.ValorSubtotal);
        iva = findViewById(R.id.ValorIVA);
        servicio = findViewById(R.id.ValorServicio);
        total = findViewById(R.id.ValorTotal);
        platos = findViewById(R.id.recyclerSubtotal);


        regresar = findViewById(R.id.b);
        pagos = findViewById(R.id.Pagar);
        actualizar = findViewById(R.id.actualizar);

        metodos = findViewById(R.id.paymentSpinner);
        factura = findViewById(R.id.facturaSpinner);

        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");
        Elden = (Order) getIntent().getSerializableExtra("Order");
        Orden.setText("Platos de la Mesa "+Elden.getNumeroMesa());
        lista = Elden.getOrdenes();

        Subtotal(Elden);

        LinearLayout l1 = findViewById(R.id.lFinal);
        LinearLayoutManager man = new LinearLayoutManager(getApplicationContext());
        platos.setLayoutManager(man);
        CheckoutAdaptador adaptador = new CheckoutAdaptador(Elden.getOrdenes(), getApplicationContext());
        adaptador.setOnItemClickListener(this);
        adaptador.setOnCartEmptyListener(this);
        adaptador.setOnFragmentDestroyListener(this);
        platos.setAdapter(adaptador);
        l1.setLayoutParams(platos.getLayoutParams());

        ProcesarSpinners();

        regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento1 = new Intent(getApplicationContext(), MenuRestaurante.class);
                intento1.putExtra("nombre_usuario", nombreUsuario);
                intento1.putExtra("QR", QR);
                intento1.putExtra("Orden", Elden);
                setResult(RESULT_OK, intento1);
                finish();
            }
        });

        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Subtotal(Elden);
                if(Elden.getOrdenes().size() == lista.size()){
                    Toast.makeText(getApplicationContext(), "Orden confirmada...", Toast.LENGTH_SHORT).show();
                }
            }
        });



        pagos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Elden.getMetodoPago() != "Sin Seleccionar"){
                    if(Elden.getMetodoPago() == "Efectivo"){
                        Toast.makeText(getApplicationContext(), "Orden creada y enviada a la cocina con exito!", Toast.LENGTH_LONG).show();
                        Envio(ResumenOrden.class);
                        MensajeOrden();
                    } else if (Elden.getMetodoPago() == "PayPal") {
                        Envio(ResumenOrdenPay.class);
                    }

                }else{
                    Toast.makeText(getApplicationContext(), "Todavia no se escoge un metodo de pago", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    public void Envio(Class tipo){
        Intent intent = new Intent(getApplicationContext(), tipo);
        intent.putExtra("nombre_usuario", nombreUsuario);
        intent.putExtra("QR", QR);
        intent.putExtra("Order",Elden);
        intent.putExtra("Resumen", convertirOrdenATexto(Elden));
        intent.putExtra("Mensaje", convertirMensaje(Elden));
        startActivity(intent);
    }




    public void Subtotal(Order orden){
        orden.setPrecioTotal(0.0);
        precio = calcularSumaPrecios(orden.getOrdenes());
        precioIva = precio * orden.getImpuestos();
        serv = precio * orden.getServicio();
        precioTotal = precio + precioIva + serv;
        orden.setPrecioTotal(precioTotal);
        InteraccionMetodos(metodos,orden);
        InteraccionFactura(factura,orden);

        String sub = String.format("%.2f",precio);
        String precioIVA = String.format("%.2f",precioIva);
        String precioServicio = String.format("%.2f",serv);
        String T= String.format("%.2f",orden.getPrecioTotal());

        subtotal.setText("$"+ sub);
        iva.setText("$"+ precioIVA);
        servicio.setText("$"+precioServicio);
        total.setText("$"+ T);
    }




    public void MensajeOrden(){
        String numero = "+593983536070";
        String mensaje = convertirMensaje(Elden);
        enviarMensajeLargo(numero, mensaje);
    }


    private void enviarMensajeLargo(String numero, String mensaje) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                ArrayList<String> partesMensaje = smsManager.divideMessage(mensaje);
                smsManager.sendMultipartTextMessage(numero, null, partesMensaje, null, null);
                Toast.makeText(getApplicationContext(), "Mensaje enviado correctamente", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Fallo al enviar el mensaje.", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }




    private String convertirMensaje(Order orden) {
        StringBuilder builder = new StringBuilder();
        String sub = String.format("%.2f",precio);
        String precioIVA = String.format("%.2f",precioIva);
        String precioServicio = String.format("%.2f",serv);
        String precioT = String.format("%.2f",orden.getPrecioTotal());


        builder.append("Cliente: ").append(orden.getCliente()).append(" (Mesa ").append(orden.getNumeroMesa()+")").append("\n");
        builder.append("Pago: ").append(orden.getMetodoPago()).append("\n");
        builder.append("Factura: ").append(orden.getFactura()).append("\n");
        builder.append("").append("\n");


        List<OrderItem> items = orden.getOrdenes();
        for (OrderItem item : items) {
            double precioCantidad = item.getPrecio()/item.getCantidad();
            String precioIndividual = String.format("%.2f",item.getPrecio());
            String precioC = String.format("%.2f",precioCantidad);
            builder.append(item.getCantidad()+" X ").append(item.getNombrePlato()).append("\n");
            builder.append("Valor: $"+precioIndividual+" ( $"+precioC+" c/u )").append("\n");
            builder.append(" ").append("\n");
        }


        builder.append("Subtotal: $").append(sub).append("\n");
        builder.append("Impuestos: $").append(precioIVA).append("\n");
        builder.append("Servicio: $").append(precioServicio).append("\n");
        builder.append("Precio Total: $").append(precioT).append("\n");

        return builder.toString();
    }



    private String convertirOrdenATexto(Order orden) {
        StringBuilder builder = new StringBuilder();
        String sub = String.format("%.2f",precio);
        String precioIVA = String.format("%.2f",precioIva);
        String precioServicio = String.format("%.2f",serv);
        String precioT = String.format("%.2f",orden.getPrecioTotal());


        builder.append("Restaurante: ").append(orden.getNombreRestaurante()).append("\n");
        builder.append("Cliente: ").append(orden.getCliente()).append(" (Mesa ").append(orden.getNumeroMesa()+")").append("\n");
        builder.append("Método de Pago: ").append(orden.getMetodoPago()).append("\n");
        builder.append("Necesita factura?: ").append(orden.getFactura()).append("\n");
        builder.append("").append("\n");

        builder.append("Platos recibidos:\n");
        List<OrderItem> items = orden.getOrdenes();
        for (OrderItem item : items) {
            double precioCantidad = item.getPrecio()/item.getCantidad();
            String precioIndividual = String.format("%.2f",item.getPrecio());
            String precioC = String.format("%.2f",precioCantidad);
            builder.append(item.getIndice()+". ").append(item.getNombrePlato()+" - QTY: "+item.getCantidad()).append("\n");
            builder.append("   Precio: $"+precioIndividual+" ( $"+precioC+" c/u )").append("\n");
        }
        builder.append("").append("\n");
        builder.append("Subtotal: $").append(sub).append("\n");
        builder.append("Impuestos: $").append(precioIVA).append("\n");
        builder.append("Servicio: $").append(precioServicio).append("\n");
        builder.append("Precio Total: $").append(precioT).append("\n");

        return builder.toString();
    }


    public void ProcesarSpinners(){
        ItemSpinner item = new ItemSpinner("Sin Seleccionar", R.drawable.baseline_clear_24);
        ItemSpinner item1 = new ItemSpinner("PayPal",R.drawable.paypal);
        ItemSpinner item2 = new ItemSpinner("Efectivo",R.drawable.dolar);
        ItemSpinner item3 = new ItemSpinner("No",R.drawable.no);
        ItemSpinner item4 = new ItemSpinner("Si",R.drawable.yes);

        m.add(item);
        m.add(item1);
        m.add(item2);
        f.add(item3);
        f.add(item4);

        if (metodos != null && m != null) { Spin(metodos, m); }
        if (factura != null && f != null) { Spin(factura, f); }
    }


    public void Spin(Spinner spin, List<ItemSpinner> el){
        spinnerAdapter adaptador = new spinnerAdapter(getApplicationContext(),el);
        spin.setAdapter(adaptador);
    }






    public void InteraccionMetodos(Spinner spin, Order o){
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ItemSpinner selectedItem = (ItemSpinner) parent.getItemAtPosition(position);
                String me = selectedItem.getNombre();
                o.setMetodoPago(me);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    public void InteraccionFactura(Spinner spin, Order orden){
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ItemSpinner selectedItem = (ItemSpinner) parent.getItemAtPosition(position);
                String fact = selectedItem.getNombre();
                orden.setFactura(fact);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }





    public double calcularSumaPrecios(List<OrderItem> orderItems) {
        double sumaPrecios = 0.0;
        for (OrderItem item : orderItems) {
            sumaPrecios += item.getPrecio();
        }
        return sumaPrecios;
    }
    @Override
    public void onItemClick(List<OrderItem>l) {
        Elden.setOrdenes(l);
    }
    @Override
    public void onCartEmptied() {
        Intent intent = new Intent(getApplicationContext(), MenuRestaurante.class);
        intent.putExtra("nombre_usuario", nombreUsuario);
        intent.putExtra("QR", QR);
        intent.putExtra("Vacio", Elden);
        setResult(RESULT_OK, intent);
        finish();
    }
    @Override
    public void onDestroyFragment(List<OrderItem>l) {
        Elden.setOrdenes(l);
    }

}