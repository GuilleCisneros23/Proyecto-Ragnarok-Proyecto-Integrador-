package com.example.fenris;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MenuRestaurante extends AppCompatActivity {
    private static final int CODIGO_PARA_ORDEN= 1;
    private static final int CODIGO_SUBTOTAL= 101;


    FirebaseStorage firebaseStorage;
    String nombreUsuario;
    String QR;
    TextView nombreRestaurante;
    TextView mesa;
    TextView cliente;
    TextView total;
    Button checkout;



    List<Platillo> platillos = new ArrayList<>();
    List<Platillo> extra = new ArrayList<>();
    List<Platillo> bebida = new ArrayList<>();



    MenuPrincipal seva;
    private List<OrderItem> listaOrdenes = new ArrayList<>();
    Order Elden;


    double precioTotal=0;
    int qta =0;
    final double impuestos = 0.12;
    final double servicio = 0.10;


    RecyclerView recyclerView1;
    RecyclerView recyclerView2;
    RecyclerView recyclerView3;
    PlatilloAdaptador platilloAdapter1;
    PlatilloAdaptador platilloAdapter2;
    PlatilloAdaptador platilloAdapter3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_menu_restaurante);
        nombreRestaurante = findViewById(R.id.Restaurante);
        mesa = findViewById(R.id.Mesa);
        cliente = findViewById(R.id.Cliente);
        total = findViewById(R.id.Total);
        recyclerView1 = findViewById(R.id.recyclerView);
        recyclerView2 = findViewById(R.id.recycleExtras);
        recyclerView3 = findViewById(R.id.recycleBebidas);
        checkout = findViewById(R.id.checkout);
        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");

        ProcesamientoQR(QR);
        UIMenu(seva);
        CheckOut();
    }





    public MenuPrincipal ProcesamientoQR(String line) {
        Pattern pattern = Pattern.compile("\\[([^\\[\\]]+)\\]");
        Matcher matcher = pattern.matcher(line);

        while (matcher.find()) {
            String texto= matcher.group(1);

            String []lines = texto.split("%");
            String Nombre = lines[0].substring(lines[0].lastIndexOf(":") + 1);
            String mesa = lines[1].substring(lines[1].lastIndexOf(":") + 1);
            String platos = lines[2].substring(lines[2].lastIndexOf("Platos<") + 1, lines[2].lastIndexOf(">"));;
            String extras = lines[3].substring(lines[3].lastIndexOf("Extras{") + 1, lines[3].lastIndexOf("}"));
            String bebidas = lines[4].substring(lines[4].lastIndexOf("Bebidas(") + 1, lines[4].lastIndexOf(")"));


            String[] p = platos.split("-");
            //Creación de los platos individuales con sus respectivas caracteristicas
            for(int i=0;i<p.length;i++){
                String platoIndividual = p[i];
                String[]elementosPlato = platoIndividual.split("/");

                String Indice = elementosPlato[0].substring(elementosPlato[0].lastIndexOf(":")+1);
                String NombrePlato = elementosPlato[1].substring(elementosPlato[1].lastIndexOf(":")+1);
                String Descripcion = elementosPlato[2].substring(elementosPlato[2].lastIndexOf(":")+1);
                double Precio = Double.parseDouble(elementosPlato[3].substring(elementosPlato[3].lastIndexOf(":")+1));
                String Imagen = elementosPlato[4].substring(elementosPlato[4].lastIndexOf(":")+1);

                Platillo plato = new Platillo(Indice,NombrePlato,Descripcion,Precio,Imagen);
                platillos.add(plato);
            }

            //Division para almacenar los Extras
            String[] e = extras.split("-");
            for(int i=0;i<e.length;i++){
                String platoIndividual = e[i];
                String[]elementosPlato = platoIndividual.split("/");

                String Indice = elementosPlato[0].substring(elementosPlato[0].lastIndexOf(":")+1);
                int indice = Integer.parseInt(Indice)+platillos.size();
                String Index = Integer.toString(indice);
                String NombrePlato = elementosPlato[1].substring(elementosPlato[1].lastIndexOf(":")+1);
                String Descripcion = elementosPlato[2].substring(elementosPlato[2].lastIndexOf(":")+1);
                double Precio = Double.parseDouble(elementosPlato[3].substring(elementosPlato[3].lastIndexOf(":")+1));
                String Imagen = elementosPlato[4].substring(elementosPlato[4].lastIndexOf(":")+1);

                Platillo plato = new Platillo(Index,NombrePlato,Descripcion,Precio,Imagen);
                extra.add(plato);
            }


            //Division para almacenar las bebidas
            String[] b = bebidas.split("-");
            for(int i=0;i<b.length;i++){
                String platoIndividual = b[i];
                String[]elementosPlato = platoIndividual.split("/");

                String Indice = elementosPlato[0].substring(elementosPlato[0].lastIndexOf(":")+1);
                int indice = Integer.parseInt(Indice)+platillos.size()+extra.size();
                String Index = Integer.toString(indice);
                String NombrePlato = elementosPlato[1].substring(elementosPlato[1].lastIndexOf(":")+1);
                String Descripcion = elementosPlato[2].substring(elementosPlato[2].lastIndexOf(":")+1);
                double Precio = Double.parseDouble(elementosPlato[3].substring(elementosPlato[3].lastIndexOf(":")+1));
                String Imagen = elementosPlato[4].substring(elementosPlato[4].lastIndexOf(":")+1);

                Platillo plato = new Platillo(Index,NombrePlato,Descripcion,Precio,Imagen);
                bebida.add(plato);
            }
            seva = new MenuPrincipal(Nombre,mesa,platillos,extra,bebida);
        }
        return seva;
    }



    public void UIMenu(MenuPrincipal seva) {
        if (seva != null) {
            nombreRestaurante.setText(seva.getNombreRestaurante());
            mesa.setText("Mesa: " + seva.getNumeroMesa());
            cliente.setText("Cliente: "+ nombreUsuario);
            List<Platillo> comidas = seva.getListaDePlatillos();;
            List<Platillo> extras = seva.getListaDeExtras();
            List<Platillo> bebidas = seva.getListaDeBebidas();

            /////////////////////////////////////////////////////////////
            LinearLayout l1 = findViewById(R.id.l1);
            LinearLayoutManager manager1 = new LinearLayoutManager(getApplicationContext());
            recyclerView1.setLayoutManager(manager1);
            ProcesarRecycle(manager1,recyclerView1,l1,comidas,platilloAdapter1);

            /////////////////////////////////////////////////////////////
            LinearLayout l2 = findViewById(R.id.l2);
            LinearLayoutManager manager2 = new LinearLayoutManager(getApplicationContext());
            recyclerView2.setLayoutManager(manager2);
            ProcesarRecycle(manager2,recyclerView2,l2,extras,platilloAdapter2);

            /////////////////////////////////////////////////////////////
            LinearLayout l3 = findViewById(R.id.l3);
            LinearLayoutManager manager3 = new LinearLayoutManager(getApplicationContext());
            recyclerView3.setLayoutManager(manager3);
            ProcesarRecycle(manager3,recyclerView3,l3,bebidas,platilloAdapter3);

        } else {
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == CODIGO_PARA_ORDEN && data != null) {
            precioTotal=0;
            OrderItem ace = (OrderItem) data.getSerializableExtra("Orden");
            listaOrdenes.add(ace);
            List<OrderItem> fusion = ListaGogeta(listaOrdenes);
            int itemsTotales = NItems(fusion);
            precioTotal = calcularSumaPrecios(fusion);
            String t = String.format("%.2f",precioTotal);
            total.setText("Platos: "+Integer.toString(itemsTotales)+"\nTotal: $"+t);
            ActualizarOrdenMenu(ace);

            if (Elden == null){
                Elden = new Order(nombreUsuario, seva.getNombreRestaurante(), seva.getNumeroMesa(),fusion,impuestos,servicio,precioTotal,null,null);
            }else if(Elden != null){
                Elden.setOrdenes(listaOrdenes);
                Elden.setPrecioTotal(precioTotal);
            }
        }

        //Caso en el que se utiliza el boton de regreso y siguen existiendo items en la actividad del Checkout
        if(resultCode == RESULT_OK && requestCode == CODIGO_SUBTOTAL && data != null) {

            if(data.hasExtra("Orden")){
                Elden = (Order) data.getSerializableExtra("Orden");
                listaOrdenes = Elden.getOrdenes();
                List<OrderItem> fusion = ListaGogeta(listaOrdenes);
                int itemsTotales = NItems(fusion);
                double sumaPrecios = calcularSumaPrecios(fusion);

                String t = String.format("%.2f",sumaPrecios);
                total.setText("Platos: " + itemsTotales + "\nTotal: $" + t);
                ActualizarOrden(listaOrdenes);


            }else if (data.hasExtra("Vacio")) {
                Elden = (Order) data.getSerializableExtra("Vacio");
                int i = 0;
                listaOrdenes.get(i).setCantidad(0);
                ActualizarOrdenMenu(listaOrdenes.get(i));
                Elden = null;
                listaOrdenes.clear();
                precioTotal = 0;
                total.setText("Platos: " + 0 + "\nTotal: $" + 0);
                Toast.makeText(getApplicationContext(), "Orden eliminada con exito...", Toast.LENGTH_SHORT).show();
            }
        }
    }








    public void ActualizarOrdenMenu(OrderItem item){
        LinearLayoutManager manager1 = new LinearLayoutManager(getApplicationContext());
        LinearLayoutManager manager2 = new LinearLayoutManager(getApplicationContext());
        LinearLayoutManager manager3 = new LinearLayoutManager(getApplicationContext());

        recyclerView1.setLayoutManager(manager1);
        LinearLayout l1 = findViewById(R.id.l1);
        recyclerView2.setLayoutManager(manager2);
        LinearLayout l2 = findViewById(R.id.l2);
        recyclerView3.setLayoutManager(manager3);
        LinearLayout l3 = findViewById(R.id.l3);

        PlatilloAdaptador p1 = Viewer(qta,platilloAdapter1,platillos);
        PlatilloAdaptador p2 = Viewer(qta,platilloAdapter2,extra);
        PlatilloAdaptador p3 = Viewer(qta,platilloAdapter3,bebida);


        p1.actualizarNumero(item.getIndice(),item.getCantidad(),platillos);
        recyclerView1.setAdapter(p1);
        l1.setLayoutParams(recyclerView1.getLayoutParams());
        p2.actualizarNumero(item.getIndice(),item.getCantidad(),extra);
        recyclerView2.setAdapter(p2);
        l2.setLayoutParams(recyclerView2.getLayoutParams());
        p3.actualizarNumero(item.getIndice(),item.getCantidad(),bebida);
        recyclerView3.setAdapter(p3);
        l3.setLayoutParams(recyclerView3.getLayoutParams());
    }


    public double calcularSumaPrecios(List<OrderItem> orderItems) {
        double sumaPrecios = 0.0;
        for (OrderItem item : orderItems) {
            sumaPrecios += item.getPrecio();
        }
        return sumaPrecios;
    }


    public void ActualizarOrden(List<OrderItem> ele){
        LinearLayoutManager manager1 = new LinearLayoutManager(getApplicationContext());
        LinearLayoutManager manager2 = new LinearLayoutManager(getApplicationContext());
        LinearLayoutManager manager3 = new LinearLayoutManager(getApplicationContext());

        recyclerView1.setLayoutManager(manager1);
        recyclerView2.setLayoutManager(manager2);
        recyclerView3.setLayoutManager(manager3);

        LinearLayout l1 = findViewById(R.id.l1);
        PlatilloAdaptador p1 = Viewer(qta,platilloAdapter1,platillos);
        recyclerView1.setAdapter(p1);
        p1.actualizarCheckout(ele,platillos);
        l1.setLayoutParams(recyclerView1.getLayoutParams());

        LinearLayout l2 = findViewById(R.id.l2);
        PlatilloAdaptador p2 = Viewer(qta,platilloAdapter2,extra);
        recyclerView2.setAdapter(p2);
        p2.actualizarCheckout(ele,extra);
        l2.setLayoutParams(recyclerView2.getLayoutParams());

        LinearLayout l3 = findViewById(R.id.l3);
        PlatilloAdaptador p3 = Viewer(qta,platilloAdapter1,bebida);
        recyclerView3.setAdapter(p3);
        p3.actualizarCheckout(ele,bebida);
        l3.setLayoutParams(recyclerView3.getLayoutParams());


    }


    public int NItems(List<OrderItem>list){
        int cantidad_total=0;

        for(OrderItem order : list){
            if(order.getCantidad() != 0){
                cantidad_total += order.getCantidad();
            }else{
                cantidad_total = 0;
            }
        }
        return cantidad_total;
    }




    public List<OrderItem> ListaGogeta(List<OrderItem> list) {
        Map<String, OrderItem> mapa = new HashMap<>();

        for (OrderItem orden : list) {
            String key;
            if (orden.getInstrucciones().isEmpty()) {
                key = orden.getIndice();
            } else {
                key = orden.getIndice() + "_" + orden.getInstrucciones();
            }
            if (mapa.containsKey(key)) {
                OrderItem existente = mapa.get(key);
                existente.setCantidad(existente.getCantidad() + orden.getCantidad());
                existente.setPrecio(existente.getPrecio() + orden.getPrecio());
            } else {
                mapa.put(key, orden);
            }
        }
        list.clear();
        list.addAll(mapa.values());


        return list;
    }


    public void ProcesarRecycle(LinearLayoutManager m, RecyclerView r,LinearLayout l,List<Platillo> P,PlatilloAdaptador p){
        m = new LinearLayoutManager(getApplicationContext());
        r.setLayoutManager(m);
        PlatilloAdaptador p2 = Viewer(qta,p,P);
        r.setAdapter(p2);
        l.setLayoutParams(r.getLayoutParams());
    }


    public PlatilloAdaptador Viewer(int q,PlatilloAdaptador platilloAdapter,List<Platillo> categoria){
        platilloAdapter = new PlatilloAdaptador(q,categoria, getApplicationContext(), QR, nombreUsuario,new PlatilloAdaptador.OnPlatoClickListener() {
            @Override
            public void onPlatoClick(Platillo plato) {
                Intent intent = new Intent(getApplicationContext(), detallesPlato.class);
                intent.putExtra("plato", plato);
                intent.putExtra("cantidad",q);
                startActivityForResult(intent, CODIGO_PARA_ORDEN);
            }
        });
        if(platilloAdapter != null){
            platilloAdapter.notifyItemInserted(q);
        }
        return platilloAdapter;
    }






    public void CheckOut(){
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Elden != null) {
                    Intent intent = new Intent(getApplicationContext(), CheckOut.class);
                    intent.putExtra("Order", Elden);
                    intent.putExtra("nombre_usuario", nombreUsuario);
                    intent.putExtra("QR", QR);
                    startActivityForResult(intent, CODIGO_SUBTOTAL);
                }else{
                    Toast.makeText(getApplicationContext(), "Debe añadir al menos '1' plato para realizar el checkout...", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intento1 = new Intent(getApplicationContext(), QRActivity.class);
        intento1.putExtra("nombre_usuario", nombreUsuario);
        startActivity(intento1);
        finish();
    }


}

