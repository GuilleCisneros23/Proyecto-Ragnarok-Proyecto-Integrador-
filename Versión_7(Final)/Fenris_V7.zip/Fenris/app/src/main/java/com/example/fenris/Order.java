package com.example.fenris;

import java.util.List;

public class Order extends MenuPrincipal {

    private String cliente;
    private List<OrderItem> ordenes;
    private Double impuestos;
    private Double servicio;
    private Double precioTotal;
    private String metodoPago;
    private String factura;


    public Order(String cliente, String nombreRestaurante, String numeroMesa, List<OrderItem>ordenes, Double impuestos, Double servicio, Double precioTotal,String metodoPago, String factura) {
        super(nombreRestaurante, numeroMesa);
        this.cliente=cliente;
        this.ordenes=ordenes;
        this.impuestos=impuestos;
        this.servicio=servicio;
        this.precioTotal=precioTotal;
        this.metodoPago=metodoPago;
        this.factura=factura;
    }


    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }


    public List<OrderItem> getOrdenes() {
        return ordenes;
    }
    public void setOrdenes(List<OrderItem> ordenes) {
        this.ordenes = ordenes;
    }



    public Double getImpuestos() {
        return impuestos;
    }
    public Double getServicio(){return servicio;}


    public Double getPrecioTotal() {return precioTotal;}
    public void setPrecioTotal(Double precioTotal) {this.precioTotal = precioTotal;}



    public String getMetodoPago() {return metodoPago;}

    public void setMetodoPago(String metodoPago) {this.metodoPago = metodoPago;}



    public String getFactura() {return factura;}

    public void setFactura(String factura) {this.factura = factura;}
}
