package com.example.fenris;

public class OrderItem extends Platillo{

    private int N_Platos;
    private String instrucciones;
    private Double precio;

    String Imagen;

    public OrderItem(int cantidad, String indice, String nombrePlato, String descripcion, String instrucciones, Double precio, String Imagen) {
        super(indice, nombrePlato, descripcion, precio,Imagen);
        this.N_Platos=cantidad;
        this.instrucciones =instrucciones;
        this.precio = precio;
        this.Imagen = Imagen;

    }


    public String getJPG(){
        Imagen = getImagen();
        return Imagen;
    }

    public int getCantidad() {
        return N_Platos;
    }

    public void setCantidad(int cantidad) {
        this.N_Platos = cantidad;
    }

    public String getInstrucciones() {
        return instrucciones;
    }

    public void setInstrucciones(String instrucciones) {
        this.instrucciones = instrucciones;
    }

    @Override
    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public void reiniciarValores() {
        setCantidad(0);
        setPrecio(0.0);
        setDescripcion(null);;
    }
}

