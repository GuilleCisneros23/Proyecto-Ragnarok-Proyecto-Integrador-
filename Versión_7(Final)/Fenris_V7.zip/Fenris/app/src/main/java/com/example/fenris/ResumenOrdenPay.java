package com.example.fenris;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.paypal.checkout.createorder.CreateOrderActions;
import com.paypal.checkout.createorder.CurrencyCode;
import com.paypal.checkout.createorder.OrderIntent;
import com.paypal.checkout.createorder.UserAction;
import com.paypal.checkout.order.Amount;
import com.paypal.checkout.order.AppContext;
import com.paypal.checkout.order.OrderRequest;
import com.paypal.checkout.order.PurchaseUnit;
import com.paypal.checkout.paymentbutton.PaymentButtonContainer;
import java.util.ArrayList;


public class ResumenOrdenPay extends AppCompatActivity {

    PaymentButtonContainer paymentButtonContainer;
    Order Elden;
    Button regresoMenu;
    Button regreso;
    TextView rewatch;


    String QR;
    String nombreUsuario;
    String Mensaje;
    String Resumen;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_resumen_orden_pay);
        paymentButtonContainer = findViewById(R.id.payment_button_container);
        regresoMenu = findViewById(R.id.MenuPrincipal);
        regreso = findViewById(R.id.RegresoMenu);
        rewatch = findViewById(R.id.ResumenPay);

        nombreUsuario = getIntent().getStringExtra("nombre_usuario");
        QR = getIntent().getStringExtra("QR");
        Resumen = getIntent().getStringExtra("Resumen");
        Mensaje = getIntent().getStringExtra("Mensaje");
        Elden = (Order) getIntent().getSerializableExtra("Order");

        String T= String.format("%.2f",Elden.getPrecioTotal());
        rewatch.setText("Realice por favor el pago por PayPal por medio del respectivo botón de pagos para procesar la orden con el establecimiento...");
        PayPal(paymentButtonContainer,T);


        regresoMenu.setOnClickListener(new View.OnClickListener() {@Override
        public void onClick(View view) {
            Intent intent = new Intent(getApplicationContext(), MenuRestaurante.class);
            intent.putExtra("nombre_usuario", nombreUsuario);
            intent.putExtra("QR", QR);
            startActivity(intent);
            }
        });

        regreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CheckOut.class);
                intent.putExtra("nombre_usuario", nombreUsuario);
                intent.putExtra("QR", QR);
                intent.putExtra("Order",Elden);
                startActivity(intent);
            }
        });


    }




    public void MensajeOrden(){
        String numero = "+593983536070";
        String mensaje = Mensaje;
        enviarMensajeLargo(numero, mensaje);
    }


    private void enviarMensajeLargo(String numero, String mensaje) {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                ArrayList<String> partesMensaje = smsManager.divideMessage(mensaje);
                smsManager.sendMultipartTextMessage(numero, null, partesMensaje, null, null);
                Toast.makeText(getApplicationContext(), "Mensaje enviado correctamente", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Fallo al enviar el mensaje.", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }



    public void PayPal(PaymentButtonContainer container, String T){
        container.setup(
                createOrderActions -> {
                    ArrayList<PurchaseUnit> purchaseUnits = new ArrayList<>();
                    purchaseUnits.add(
                            new PurchaseUnit.Builder()
                                    .amount(
                                            new Amount.Builder()
                                                    .currencyCode(CurrencyCode.USD)
                                                    .value(T)
                                                    .build()
                                    ).build()
                    );
                    OrderRequest order = new OrderRequest(
                            OrderIntent.CAPTURE,
                            new AppContext.Builder()
                                    .userAction(UserAction.PAY_NOW)
                                    .build(),
                            purchaseUnits
                    );
                    createOrderActions.create(order, (CreateOrderActions.OnOrderCreated) null);
                },
                approval -> {
                    Toast.makeText(getApplicationContext(), "Orden procesada y enviada a la cocina con exito!", Toast.LENGTH_LONG).show();
                    rewatch.setText(Resumen);
                    MensajeOrden();
                    container.setVisibility(View.GONE);
                }
        );
    }




}