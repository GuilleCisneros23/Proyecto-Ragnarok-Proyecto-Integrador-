package com.example.fenris;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class spinnerAdapter extends BaseAdapter {

    private Context context;
    private List<ItemSpinner> lista;


    public spinnerAdapter(Context context,List<ItemSpinner> lista) {
        this.context = context;
        this.lista = lista;
    }

    @Override
    public int getCount() {
        return lista != null ? lista.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return lista != null && position < lista.size() ? lista.get(position) : null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View raiz = convertView;
        ViewHolder holder;

        if (raiz == null) {
            raiz = LayoutInflater.from(context).inflate(R.layout.spinner_item, parent, false);
            holder = new ViewHolder();
            holder.nombre = raiz.findViewById(R.id.NombrePagos);
            holder.imagen = raiz.findViewById(R.id.Logos);
            raiz.setTag(holder);
        } else {
            holder = (ViewHolder) raiz.getTag();
        }

        ItemSpinner currentItem = lista.get(position);
        if (currentItem != null) {
            holder.nombre.setText(currentItem.getNombre());
            holder.imagen.setImageResource(currentItem.getImagen());
        }

        return raiz;
    }

    static class ViewHolder {
        TextView nombre;
        ImageView imagen;
    }


}
